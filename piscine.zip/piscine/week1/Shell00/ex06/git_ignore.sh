git ls-files --others --exclude-standard --ignored
